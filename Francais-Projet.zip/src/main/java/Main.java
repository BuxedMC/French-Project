import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;

public class Main extends JPanel implements ActionListener, MouseListener {
    private final int WIDTH = 800;
    private final int HEIGHT = 600;
    private final int TIME_LIMIT = 20; // in seconds per question
    private int lives = 3;
    private int questionIndex = 0;
    private int timeRemaining = TIME_LIMIT;
    private Timer timer;
    private boolean answered = false;
    private String message = ""; // Message to display when a life is lost
    private boolean showMessage = false; // Whether to display the life-loss message
    private boolean gameOver = false;

    // Questions and answers
    private String[][] questions = {
        {"Qui était la personne qui avait crée la sculpture David?", "Michel-Ange", "Léonard de Vinci", "Claude Monet", "Ludwig van Beethoven", "Michel-Ange"},
        {"Qui a laissé son empreinte sur l’art de la Renaissance?", "L'Italie", "La France", "Les Grecs anciens", "Les Romains de l'Antiquité", "Les Grecs anciens"},
        {"Quelles artistes n'etait pas mentionné qui étaient révolutionnaires à leur époque?", "Léonardo da Vinci", "Michel-Ange", "Filippo Brunelleschi", "Nicolaus Copernicus", "Nicolaus Copernicus"},
        {"La ville qui a été mentionné ou il y a eu une révolution de pensée sur les sujets de l’art, de la science et des politiques se situe en quelle pays?", "La France", "L'Allemagne", "L'Italie", "La Russie", "L'Italie"}
    };

    public Main() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.WHITE);
        addMouseListener(this);
        startNewRound();
    }

    private void startNewRound() {
        if (questionIndex >= questions.length) {
            endGame("BIEN FAIT, VOUS AVEZ FINI LE JEU AVEC " + lives + " VIE" + (lives > 1 ? "S" : ""));
            return;
        }

        timeRemaining = TIME_LIMIT;
        answered = false;  // Reset answered status for each new question
        showMessage = false;

        if (timer != null) timer.cancel();
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if (timeRemaining <= 0 && !answered) {
                    loseLife("INCORRECTE, VOUS PERDEZ UNE VIE");
                } else if (timeRemaining > 0) {
                    timeRemaining--;
                    repaint();
                }
            }
        }, 1000, 1000);
        repaint();
    }

    private void loseLife(String lifeLostMessage) {
        lives--;
        message = lifeLostMessage;
        showMessage = true;
        answered = true;

        repaint(); // Make sure the message is displayed immediately

        if (lives <= 0) {
            endGame("Vous avez perdu toutes vos vies ! Jeu Terminé!");
        } else {
            timer.cancel();
            // Schedule the message to disappear and move to the next question
            new Timer().schedule(new TimerTask() {
                public void run() {
                    showMessage = false;
                    questionIndex++;
                    startNewRound();
                }
            }, 2000); // Display the message for 2 seconds
        }
    }

    private void endGame(String message) {
        gameOver = true;
        if (timer != null) timer.cancel();
        JOptionPane.showMessageDialog(this, message);
        System.exit(0);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setFont(new Font("Arial", Font.PLAIN, 20));
        g.drawString("Time: " + timeRemaining + "s", 20, 30);
        g.drawString("Lives: " + lives, WIDTH - 100, 30);

        if (showMessage) {
            g.setFont(new Font("Arial", Font.BOLD, 36));
            g.setColor(Color.RED);
            g.drawString(message, WIDTH / 2 - g.getFontMetrics().stringWidth(message) / 2, HEIGHT / 2);
            return;
        }

        if (gameOver) return;

        String[] currentQuestion = questions[questionIndex];
        drawWrappedText(g, currentQuestion[0], 20, 100, WIDTH - 40);

        int yOffset = 200;
        int rectHeight = 50;

        for (int i = 1; i <= 4; i++) {
            String answer = currentQuestion[i];
            int rectWidth = g.getFontMetrics().stringWidth(answer) + 40;
            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(50, yOffset + (i * 70), rectWidth, rectHeight);
            g.setColor(Color.BLACK);
            g.drawRect(50, yOffset + (i * 70), rectWidth, rectHeight);
            g.drawString(answer, 70, yOffset + (i * 70) + 30);
        }
    }

    private void drawWrappedText(Graphics g, String text, int x, int y, int maxWidth) {
        FontMetrics metrics = g.getFontMetrics();
        int lineHeight = metrics.getHeight();
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();

        for (String word : words) {
            if (metrics.stringWidth(line + word) < maxWidth) {
                line.append(word).append(" ");
            } else {
                g.drawString(line.toString(), x, y);
                y += lineHeight;
                line = new StringBuilder(word + " ");
            }
        }
        g.drawString(line.toString(), x, y);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (answered || showMessage || gameOver) return;

        int x = e.getX();
        int y = e.getY();

        String[] currentQuestion = questions[questionIndex];
        String correctAnswer = currentQuestion[5];

        int yOffset = 200;
        int rectHeight = 50;

        for (int i = 1; i <= 4; i++) {
            int rectWidth = getFontMetrics(getFont()).stringWidth(currentQuestion[i]) + 40;
            if (x >= 50 && x <= 50 + rectWidth && y >= yOffset + (i * 70) && y <= yOffset + (i * 70) + rectHeight) {
                String selectedAnswer = currentQuestion[i];
                if (selectedAnswer.equals(correctAnswer)) {
                    JOptionPane.showMessageDialog(this, "Vous avez choisi la bonne réponse! Bien fait!");
                    answered = true;
                    questionIndex++;
                    startNewRound();
                } else {
                    loseLife("INCORRECTE, VOUS PERDEZ UNE VIE");
                }
                break;
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) { }

    @Override
    public void mousePressed(MouseEvent e) { }

    @Override
    public void mouseReleased(MouseEvent e) { }

    @Override
    public void mouseEntered(MouseEvent e) { }

    @Override
    public void mouseExited(MouseEvent e) { }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Quiz Shooter Game");
        Main game = new Main();
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
